#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define NUM_THREADS 2

// Global variables for producer and consumer
int count;
int N;
char *queue;
int producer_index;
int consumer_index;
pthread_mutex_t mutex;
pthread_cond_t producer_cond;
pthread_cond_t consumer_cond;
FILE *message;
char current_char;

// Producer thread function
void *producer(void *threadid) {
    // Lock mutex
    pthread_mutex_lock(&mutex);

    // Read characters until the end of file is written
    while ((current_char = (char)fgetc(message)) != EOF) {

	// Check if producer needs to wait
	if (count == N) {
	    pthread_cond_wait(&producer_cond, &mutex);
	}

	// Add character queue
        count++;
	queue[producer_index] = current_char;
        if (producer_index + 1 == N) {
	    producer_index = 0;
        }
        else {
	    producer_index++;
        }

	// Check if consumer can be signalled
        if (count == 1) {
	    pthread_cond_signal(&consumer_cond);
        }
    }

    // Unlock mutex
    pthread_mutex_unlock(&mutex);
}

// Function for consumer thread
void *consumer(void* threadid) {
    // Lock mutex
    pthread_mutex_lock(&mutex);

    // Loop while there are remaining characters in the queue
    while(count >= 0) {
	
	// Check if consumer needs to wait
	if (count == 0) {
	    pthread_cond_wait(&consumer_cond, &mutex);
	}

	// Display character from queue to stdout
	count--;
	printf("%c", queue[consumer_index]);

	if (consumer_index + 1 == N) {
	    consumer_index = 0;
	}
	else {
	    consumer_index++;
	}

	// Check if producer can be signalled
	if (count == N - 1 && current_char != EOF) {
	    pthread_cond_signal(&producer_cond);
	}

	// Check if all character have been displayed
	if (count == 0 && current_char == EOF) {
	    break;
	}
    }
    
    // Unlock mutex
    pthread_mutex_unlock(&mutex);
}

int main(void) {
    // Location to store producer and consumer threads
    pthread_t threads[NUM_THREADS];

    // Initialize global variables
    count = 0;
    N = 15;
    queue = malloc(N * sizeof(char));
    producer_index = 0;
    consumer_index = 0;

    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&producer_cond, NULL);
    pthread_cond_init(&consumer_cond, NULL);
    message = fopen("message.txt", "r");


    // Create threads
    pthread_create(&threads[0], NULL, producer, (void *) 0);
    pthread_create(&threads[1], NULL, consumer, (void *) 1);

    // Wait for threads to finish
    int i;
    for (i = 0; i < NUM_THREADS; i++) {
	int rc = pthread_join(threads[i], NULL);

	if (rc) {
	    printf("ERROR; return code from pthread_join() is %d\n", rc);
	    exit(-1);
	}
    }

    // Free declared memory
    free(queue);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&producer_cond);
    pthread_cond_destroy(&consumer_cond);
    pthread_exit(NULL);
}







